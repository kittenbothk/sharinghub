# Future LiteAI standalone 05.Temp_p1.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from machine import Pin
import onewire
import ds18x20
import time

sensors = Sensor()
ow = onewire.OneWire(Pin(4))
ds = ds18x20.DS18X20(ow)
roms = ds.scan()
screens = Screen()
screens.autoRefresh(False)


temperature_sample = None
temperature_error = "No temp sensor" if not roms else ""
conversion_started = None
last_conversion_attempt = time.ticks_add(time.ticks_ms(), -1000)

def temperature_step(now_ms):
    # A DS18B20 conversion runs on the sensor while the main loop draws the screen.
    global temperature_sample, temperature_error, conversion_started, last_conversion_attempt
    if not roms:
        temperature_sample = None
        temperature_error = "No temp sensor"
        return
    try:
        if conversion_started is None:
            if time.ticks_diff(now_ms, last_conversion_attempt) < 1000:
                return
            last_conversion_attempt = now_ms
            ds.convert_temp()
            conversion_started = time.ticks_ms()
        elif time.ticks_diff(now_ms, conversion_started) >= 750:
            conversion_started = None
            value = float(ds.read_temp(roms[0]))
            if value == 85.0 or not (-55.0 <= value <= 125.0):
                raise ValueError("Invalid temperature")
            now = time.localtime()
            timestamp = "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(*now[:6])
            temperature_sample = (timestamp, value)
            temperature_error = ""
    except Exception as error:
        conversion_started = None
        temperature_sample = None
        temperature_error = "Temp sensor error"
        print("Temperature sensor error:", error)



SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        temperature_step(time.ticks_ms())
        screens.fill((0, 0, 0))
        screens.text("水溫:", 5, 10, 2, (255, 255, 255))
        value_text = "{:.1f} C".format(temperature_sample[1]) if temperature_sample else "-- C"
        screens.text(value_text, 5, 40, 3, (255, 255, 255))
        visible_status = temperature_error or ""
        if visible_status:
            screens.text(visible_status, 5, 80, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

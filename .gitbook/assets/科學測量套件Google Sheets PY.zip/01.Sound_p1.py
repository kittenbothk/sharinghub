# Future LiteAI standalone 01.Sound_p1.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from modulesplus import *
import time

sensors = Sensor()
P1 = MeowPin("P1", "ANALOG")
DB_p1 = DBNoise(P1)
screens = Screen()
screens.autoRefresh(False)




SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        sound_db = DB_p1.getDB()
        screens.fill((0, 0, 0))
        screens.text("分貝值:", 5, 10, 2, (255, 255, 255))
        screens.text(str(sound_db) + " dB", 5, 40, 2, (255, 255, 255))
        visible_status = ""
        if visible_status:
            screens.text(visible_status, 5, 80, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

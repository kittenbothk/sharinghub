# Future LiteAI standalone 02.HPA_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from sugar import ENV2
import time

sensors = Sensor()
env2 = ENV2()
screens = Screen()
screens.init()
screens.autoRefresh(False)




SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        pressure_hpa = env2.read_pres()
        screens.fill((0, 0, 0))
        screens.text("氣壓(hPa):", 5, 10, 2, (255, 255, 255))
        screens.text(str(pressure_hpa), 5, 40, 2, (255, 255, 255))
        screens.text("hPa", 130, 45, 1, (255, 255, 255))
        visible_status = ""
        if visible_status:
            screens.text(visible_status, 5, 80, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

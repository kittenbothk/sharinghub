import time
import board
import struct
from screen import Screen

__version__ = "1.0.1"
screens = Screen()

class Solar:
    ADDR = 37
    def __init__(self):
        self.i2c = board.i2c
        #self.i2c.try_lock()
        screens.autoRefresh(False)

        # 等待直到设备连接到I2C接口
        connected = False
        while not connected:
            try:
                if self.ADDR in self.i2c.scan():
                    connected = True
                else:
                    screens.fill((0, 0, 0))
                    screens.text('未检测到电源管理模块',5,10,1,(255, 255, 255))
                    screens.refresh()
            except Exception as e:
                pass
        
    def reg_write(self, reg, buff):
        buf = bytearray([reg])
        if isinstance(buff, int):
            buf.append(buff)
        else:
            buf.extend(buff)
        self.i2c.writeto(self.ADDR, buf)
        time.sleep(0.2)

    def reg_read(self, reg, n=1):
        # 先写入寄存器地址
        self.i2c.writeto(self.ADDR, bytes([reg]))
        out = self.i2c.readfrom(self.ADDR, n)
        if len(out) == 1:
            return out[0]
        return out

    def version(self):
        return self.reg_read(0x00, 1)
    

    def battery_level(self):
        buf = self.reg_read(0x02, 4)
        bat = struct.unpack('f', buf)
        return bat[0]
    
    def set_power(self, val):
        self.reg_write(0x03, val)

    def set_rtc(self, yy, mm, dd, hh, mn, ss):
        if yy > 2000:
            yy -= 2000
        self.reg_write(0x05, bytearray([yy, mm, dd, hh, mn, ss]))

    def read_rtc(self):
        [yy, mm, dd, hh, mn, ss] = self.reg_read(0x06, 6)
        yy += 2000
        return (yy, mm, dd, hh, mn, ss)
    
    def set_alarm(self, hh, mm, ss, down=0):
        self.reg_write(0x04, bytearray([hh, mm, ss, down]))
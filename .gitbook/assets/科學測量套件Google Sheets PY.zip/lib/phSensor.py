import struct
import board  # 使用 board 封装好的 I2C 对象
from micropython import const

__version__ = "1.2.0"

_PH_SENSOR_ADDR = const(0x54)
_PH_REG_VALUE = const(0x03)
_PH_REG_ADC   = const(0x04)

class PHSensor:
    """
    MicroPython-compatible driver for a generic I2C pH sensor at address 0x54.
    Uses board.i2c as the I2C bus interface.
    """

    def __init__(self, address: int = _PH_SENSOR_ADDR):
        self._addr = address
        self._i2c = board.i2c  # 使用 board.i2c 代替手动创建 I2C 对象

    @property
    def ph(self) -> float:
        """
        Read and return the calibrated pH value as a float.
        """
        buf = self._i2c.readfrom_mem(self._addr, _PH_REG_VALUE, 4)
        raw_ph = struct.unpack_from('<f', buf, 0)[0]
        return round(raw_ph, 2)

    @property
    def ph_adc(self) -> int:
        """
        Read and return the raw ADC value (16-bit unsigned, big-endian).
        """
        buf = self._i2c.readfrom_mem(self._addr, _PH_REG_ADC, 2)
        return struct.unpack_from('>H', buf, 0)[0]

    def reset(self) -> None:
        """
        Placeholder for reset logic, if supported by the sensor.
        """
        pass

import time
#from board_map import usePin, saveObj

__version__ = "0.0.4"

class ANALOG:
    def __init__(self, pin):
        self.pin = pin
        #self.p = usePin(pin)
        #saveObj(pin)

class Turbidity(ANALOG):
    _wtemp = 25
    _deltaU = 0
    _U = 0
    _U25 = 0
    _K = 2600

    def __init__(self, pin):
        super(Turbidity, self).__init__(pin)

    def turCali(self, wt):
        Turbidity._deltaU = -0.0192 * (wt - 25)
        Turbidity._U = self.pin.getAnalog() / 4096 * 5
        Turbidity._U25 = Turbidity._U - Turbidity._deltaU
        Turbidity._K = 865.68 * Turbidity._U25
        print("K:" + str(Turbidity._K))

    def getNTU(self):
        Turbidity._U = self.pin.getAnalog() / 4096 * 5
        NTU = (-865.8 * Turbidity._U) + Turbidity._K
        #print(self.pin.getAnalog())
        if NTU > 0:
            return int(NTU)
        else:
            return 0

class DBNoise(ANALOG):
    def __init__(self, pin):
        super(DBNoise, self).__init__(pin)

    def map(self, value, leftMin, leftMax, rightMin, rightMax):
        leftSpan = leftMax - leftMin
        rightSpan = rightMax - rightMin
        valueScaled = float(value - leftMin) / float(leftSpan)
        db = rightMin + (valueScaled * rightSpan)
        return db

    def getDB(self):
        '''
        samples = [self.pin.getAnalog() for _ in range(200)]
        avg = sum(samples) / len(samples)
        rms = (sum((s - avg) ** 2 for s in samples) / len(samples)) ** 0.5
        db = self.map(rms, leftMin=0, leftMax=600, rightMin=30, rightMax=120)
        return round(db, 1)
        '''

        level = 0
        noise = 0
        high = 0
        low = 0
        sumh = 0
        suml = 0
        for i in range(1000):
            level += self.pin.getAnalog() / 4
        level /= 1000
        for i in range(1000):
            voltage = self.pin.getAnalog() / 4
            if voltage >= level:
                high += 1
                sumh += voltage
            else:
                low += 1
                suml += voltage
        sumh = sumh / high if high != 0 else level
        suml = suml / low if low != 0 else level
        noise = sumh - suml
        print(noise)
        if noise <= 11:
            noise = self.map(value=noise, leftMin=0, leftMax=11, rightMin=30, rightMax=50)
        elif noise <= 16:
            noise = self.map(value=noise, leftMin=12, leftMax=16, rightMin=50, rightMax=55)
        elif noise <= 30:
            noise = self.map(value=noise, leftMin=17, leftMax=30, rightMin=55, rightMax=60)
        elif noise <= 64:
            noise = self.map(value=noise, leftMin=31, leftMax=65, rightMin=60, rightMax=70)
        elif noise <= 118:
            noise = self.map(value=noise, leftMin=66, leftMax=118, rightMin=70, rightMax=75)
        elif noise <= 196:
            noise = self.map(value=noise, leftMin=119, leftMax=196, rightMin=75, rightMax=80)
        elif noise <= 288:
            noise = self.map(value=noise, leftMin=197, leftMax=288, rightMin=80, rightMax=85)
        elif noise <= 438:
            noise = self.map(value=noise, leftMin=289, leftMax=438, rightMin=85, rightMax=90)
        else:
            noise = self.map(value=noise, leftMin=439, leftMax=1023, rightMin=90, rightMax=120)
        return round(noise, 1)

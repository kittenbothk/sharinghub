# Future LiteAI standalone 04.PM_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from pmsa003i import PMSA003I
import time

sensors = Sensor()
pm = PMSA003I()
screens = Screen()
screens.autoRefresh(False)




SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        pm_values = pm.read()
        pm25 = float(pm_values[1])
        pm10 = float(pm_values[2])
        screens.fill((0, 0, 0))
        screens.text("PM2.5 (ug/m3):", 5, 10, 1, (255, 255, 255))
        screens.text(str(pm25), 5, 25, 2, (255, 255, 255))
        screens.text("PM10 (ug/m3):", 5, 50, 1, (255, 255, 255))
        screens.text(str(pm10), 5, 65, 2, (255, 255, 255))
        visible_status = ""
        if visible_status:
            screens.text(visible_status, 5, 84, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

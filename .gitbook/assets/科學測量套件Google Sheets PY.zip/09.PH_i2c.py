# Future LiteAI standalone 09.PH_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from phSensor import PHSensor
import time

sensors = Sensor()
time.sleep(5)
ph_sensor = PHSensor()
screens = Screen()
screens.init()
screens.autoRefresh(False)


def ph_color(value):
    # Illustrative universal-indicator palette, not a calibrated test-strip match.
    if value is None or not (0 <= value <= 14):
        return (180, 180, 180)
    if value < 2:
        return (229, 57, 53)
    if value < 4:
        return (207, 84, 0)
    if value < 6:
        return (148, 112, 0)
    if value < 6.5:
        return (108, 134, 27)
    if value < 7.5:
        return (35, 135, 61)
    if value < 9:
        return (0, 135, 128)
    if value < 11:
        return (36, 102, 204)
    if value < 15:
        return (128, 64, 180)


ph_error = ""

SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        try:
            ph_value = float(ph_sensor.ph)
            if not (-float("inf") < ph_value < float("inf")):
                raise ValueError("Invalid pH reading")
            ph_error = ""
        except Exception as error:
            ph_value = None
            ph_error = "pH module error"
            print("pH module error:", error)
        screens.fill((0, 0, 0))
        screens.text("pH值:", 5, 10, 2, (255, 255, 255))
        value_text = "{:.2f}".format(ph_value) if ph_value is not None else "--"
        screens.text(value_text, 5, 40, 3, ph_color(ph_value))
        if ph_error:
            screens.text("please replug", 5, 70, 1, (255, 80, 80))
        visible_status = ph_error or ""
        if visible_status:
            screens.text(visible_status, 5, 80, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

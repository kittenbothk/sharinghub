# Future LiteAI standalone 03.CO2_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from sugar_co2 import Sugarco2
import time

sensors = Sensor()
co2 = Sugarco2()
peak = 0
screens = Screen()
screens.autoRefresh(False)




SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        co2_ppm = co2.CO2
        if co2_ppm > peak:
            peak = co2_ppm
        if sensors.btnValue('a'):
            peak = 0
        screens.fill((0, 0, 0))
        screens.text("二氧化碳讀數", 5, 10, 2, (255, 255, 255))
        screens.text(str(co2_ppm), 5, 40, 3, (255, 255, 255))
        screens.text("ppm", 120, 50, 1, (255, 255, 255))
        screens.text("峰值讀數:" + str(peak) + " ppm", 5, 72, 1, (255, 255, 255))
        visible_status = ""
        if visible_status:
            screens.text(visible_status, 5, 84, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

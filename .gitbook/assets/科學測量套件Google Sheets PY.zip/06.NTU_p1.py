# Future LiteAI standalone 06.NTU_p1.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from modulesplus import Turbidity
import time

sensors = Sensor()
P1 = MeowPin("P1", "ANALOG")
turbidity_p1 = Turbidity(P1)
screens = Screen()
screens.autoRefresh(False)



a_was_pressed = False
calibration_error = ""
calibration_until = None
sensor_error = ""

SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        a_pressed = bool(sensors.btnValue('a'))
        if a_pressed and not a_was_pressed:
            try:
                turbidity_p1.turCali(25)
                calibration_error = ""
                calibration_until = time.ticks_add(time.ticks_ms(), 1500)
            except Exception as error:
                calibration_error = "Calibration failed"
                print("Calibration failed:", error)
        a_was_pressed = a_pressed
        try:
            ntu_value = turbidity_p1.getNTU()
            if not isinstance(ntu_value, (int, float)) or not (0 <= ntu_value < float("inf")):
                raise ValueError("Invalid turbidity reading")
            sensor_error = ""
        except Exception as error:
            ntu_value = None
            sensor_error = "NTU sensor error"
            print("NTU sensor error:", error)
        screens.fill((0, 0, 0))
        screens.text("水濁度:", 5, 10, 2, (255, 255, 255))
        screens.text(str(ntu_value) if ntu_value is not None else "--", 5, 40, 3, (255, 255, 255))
        screens.text("NTU", 120, 50, 1, (255, 255, 255))
        calibration_note = "校正OK" if calibration_until is not None and time.ticks_diff(time.ticks_ms(), calibration_until) < 0 else "清水按A校正"
        screens.text(calibration_note, 5, 72, 1, (255, 255, 255))
        visible_status = calibration_error or sensor_error or ""
        if visible_status:
            screens.text(visible_status, 5, 84, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

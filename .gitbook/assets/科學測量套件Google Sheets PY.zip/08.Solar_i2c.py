# Future LiteAI standalone 08.Solar_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from sugar_solar import Solar
import time

sensors = Sensor()
solar = Solar()
screens = Screen()
screens.autoRefresh(False)



a_was_pressed = False
usb_enabled = None
usb_error = ""
sensor_error = ""
# Preserve the original startup setting: USB output on.
try:
    solar.set_power(1)
    usb_enabled = True
except Exception as error:
    usb_error = "USB output error"
    print("USB output error:", error)

SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        a_pressed = bool(sensors.btnValue('a'))
        if a_pressed and not a_was_pressed:
            try:
                next_usb = not usb_enabled
                solar.set_power(1 if next_usb else 0)
                usb_enabled = next_usb
                usb_error = ""
            except Exception as error:
                usb_error = "USB output error"
                print("USB output error:", error)
        a_was_pressed = a_pressed
        try:
            voltage_v = float(solar.battery_level())
            if not (0 <= voltage_v < float("inf")):
                raise ValueError("Invalid battery voltage")
            sensor_error = ""
        except Exception as error:
            voltage_v = None
            sensor_error = "Solar sensor error"
            print("Solar sensor error:", error)
        screens.fill((0, 0, 0))
        screens.text("太陽能電池電壓:", 5, 5, 1, (255, 255, 255))
        value_text = "{:.2f}V".format(voltage_v) if voltage_v is not None else "--V"
        screens.text(value_text, 5, 25, 2, (255, 255, 255))
        screens.text("按A打開/關閉USB輸出", 5, 55, 1, (255, 255, 255))
        usb_label = "未知" if usb_enabled is None else ("開" if usb_enabled else "關")
        usb_color = (0, 170, 0) if usb_enabled else (170, 0, 0)
        screens.text("USB輸出:" + usb_label, 5, 72, 1, usb_color)
        visible_status = usb_error or sensor_error or ""
        if visible_status:
            screens.text(visible_status, 5, 84, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

from future import *
from screen import Screen


buzzer = Buzz()
screens = Screen()


screens.fill((0, 0, 0))
screens.text('蜂鳴器正在發聲',5,10,2,(255, 255, 255))
screens.refresh()
while True:
  buzzer.tone(1000, 30)

# Future LiteAI standalone 07.Load_i2c.py
# Local display only: no Wi-Fi, Google configuration or logging required.
from future import *
from screen import Screen
from sensor import Sensor
from sugar_loadcell import SugarLoadcell
import time

sensors = Sensor()
buzzer = Buzz()
myScale = SugarLoadcell()
screens = Screen()
screens.init()
screens.autoRefresh(False)
screens.fill((0, 0, 0))
screens.text("移除所有重量", 5, 10, 2, (0, 255, 170))
screens.refresh()
myScale.begin()
time.sleep(3)



a_was_pressed = False
tare_error = ""
tare_until = None
sensor_error = ""

SCREEN_INTERVAL_MS = 200

while True:
    frame_started = time.ticks_ms()
    try:
        a_pressed = bool(sensors.btnValue('a'))
        if a_pressed and not a_was_pressed:
            try:
                myScale.setPeel()
                tare_error = ""
                tare_until = time.ticks_add(time.ticks_ms(), 1500)
                buzzer.tone(440, 0.2)
            except Exception as error:
                tare_error = "Tare failed"
                print("Tare failed:", error)
        a_was_pressed = a_pressed
        try:
            weight_g = float(myScale.getWeightPeel())
            if not (-float("inf") < weight_g < float("inf")):
                raise ValueError("Invalid weight reading")
            sensor_error = ""
        except Exception as error:
            weight_g = None
            sensor_error = "Load sensor error"
            print("Load sensor error:", error)
        screens.fill((0, 0, 0))
        screens.text("重量(g):", 5, 10, 2, (255, 255, 255))
        screens.text(str(int(weight_g)) + "g" if weight_g is not None else "--g", 5, 40, 3, (255, 255, 255))
        tare_note = "歸零成功" if tare_until is not None and time.ticks_diff(time.ticks_ms(), tare_until) < 0 else "按A歸零"
        screens.text(tare_note, 5, 72, 1, (0, 170, 170))
        visible_status = tare_error or sensor_error or ""
        if visible_status:
            screens.text(visible_status, 5, 84, 1, (255, 80, 80))
    except Exception as error:
        print("Sensor/display error:", error)
        screens.fill((0, 0, 0))
        screens.text("Sensor error", 5, 40, 1, (255, 80, 80))
        screens.text("Check connection", 5, 60, 1, (255, 80, 80))
    screens.refresh()
    elapsed = time.ticks_diff(time.ticks_ms(), frame_started)
    time.sleep_ms(max(1, SCREEN_INTERVAL_MS - elapsed))

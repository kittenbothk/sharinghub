from future import *
from sensor import Sensor
from koi2 import KOI2
from screen import Screen

herbs = []
index = 0
screens = Screen()
sensors = Sensor()


koi = KOI2('uart0')
koi.setModel(5)
koi.direction(2)
koi.classifierLoad('/flash/'+'herb.json')
herbs.clear()
herbs.append('ChineseYam')
herbs.append('Chrysanthemum')
herbs.append('Wolfberry')
herbs.append('CodonopsisPilosula')
herbs.append('WolfiporiaExtensa')
index = 1
screens.autoRefresh(False)
while True:
  if sensors.btnValue('a'):
    koi.classifierAddTag(herbs[int(index - 1)])
    sleep(0.3)
  if sensors.btnValue('b'):
    index += 1
    if index > len(herbs):
      index = 1
    sleep(0.3)
  if sensors.btnValue('m'):
    koi.classifierSave('/flash/'+'herb.json')
    sleep(0.3)
  screens.fill((0, 0, 0))
  screens.text('Current Tag:',5,10,1,(255, 255, 255))
  screens.text((herbs[int(index - 1)]),5,30,2,(0, 170, 0))
  screens.text('Press A to record',5,90,1,(255, 255, 255))
  screens.text('Press B for next tag',5,100,1,(255, 255, 255))
  screens.text('Press M to save',5,110,1,(255, 255, 255))
  screens.refresh()

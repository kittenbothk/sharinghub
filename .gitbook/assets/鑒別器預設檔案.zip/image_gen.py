"""
语音生图程序：通过语音输入描述，生成2D黑白图并显示在屏幕上，并可打印
"""
from screen import Screen
from board import *
from wifi import *
from sugar_thermal_printer import SugarThermalPrinter
import time
import gc

# ============ WiFi 配置 ============
WIFI_NAME = 'CODING101M'
WIFI_PASSWORD = 'coding101.hk'
# ===================================

# 初始化屏幕
s = Screen()
s.autoRefresh(False)
BG_COLOR = 0x000000

# 初始化打印机
printer = SugarThermalPrinter("uart1")
printer.set_print_density(4000)
printer.set_line_gap(6)

# 居中辅助函数
def get_center_position(text, size=1, screen_w=160, screen_h=128):
    chinese_w, english_w, number_w, space_w, char_h = 12, 7, 7, 6, 12
    total_width = 0
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff':
            total_width += chinese_w
        elif ch.isdigit():
            total_width += number_w
        elif ch == ' ':
            total_width += space_w
        else:
            total_width += english_w
    w, h = total_width * size, char_h * size
    x, y = (screen_w - w) // 2, (screen_h - h) // 2
    return x, y, w, h

# 分行显示文本
def display_wrapped_text(text, start_y, size=1, color=0xFFFFFF):
    max_width = 150
    chinese_w, english_w, number_w, space_w, char_h = 12, 7, 7, 6, 12
    char_h_scaled = char_h * size
    line_spacing = 4
    current_line = ""
    current_width = 0
    lines = []
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff':
            char_width = chinese_w
        elif ch.isdigit():
            char_width = number_w
        elif ch == ' ':
            char_width = space_w
        else:
            char_width = english_w
        char_width *= size
        if current_width + char_width > max_width and current_line:
            lines.append(current_line)
            current_line = ch
            current_width = char_width
        else:
            current_line += ch
            current_width += char_width
    if current_line:
        lines.append(current_line)
    for i, line in enumerate(lines):
        if start_y + i * (char_h_scaled + line_spacing) < 128:
            line_width = 0
            for ch in line:
                if '\u4e00' <= ch <= '\u9fff':
                    line_width += chinese_w
                elif ch.isdigit():
                    line_width += number_w
                elif ch == ' ':
                    line_width += space_w
                else:
                    line_width += english_w
            line_width *= size
            x = (160 - line_width) // 2
            s.text(line, x, start_y + i * (char_h_scaled + line_spacing), size, color)

# 显示启动画面
s.rect(0, 0, 160, 128, BG_COLOR, 1)
tx, ty, _, _ = get_center_position("語音生圖", 2)
s.text("語音生圖", tx, ty, 2, 0xFFFF00)
s.refresh()
time.sleep(1)

# 连接WiFi
s.rect(0, 0, 160, 128, BG_COLOR, 1)
cx, cy, _, _ = get_center_position("連線中...", 1)
s.text("連線中...", cx, cy, 1, 0xFFFFFF)
s.refresh()

if not isconnected():
    connect_wifi(WIFI_NAME, WIFI_PASSWORD)

for _ in range(30):
    if isconnected():
        break
    time.sleep(0.5)

if not isconnected():
    cx, cy, _, _ = get_center_position("WiFi失敗", 1)
    s.text("WiFi失敗", cx, cy, 1, 0xFF0000)
    s.refresh()
    raise SystemExit("WiFi连接失败")

# 生成图片
def generate_image(description):
    """根据语音描述生成2D黑白图并显示"""
    try:
        from agent import Agent
        agent = Agent()
        
        prompt = f"{description}，图片尺寸160x128像素，2D黑白線條图，避免採用大量黑色的進行填色，生成图片并保存到文件系统"
        #prompt = f"{description}，图片比例為4:3，2D黑白图，避免採用大量黑色的進行填色，生成图片并保存到文件系统"
        s.rect(0, 0, 160, 128, BG_COLOR, 1)
        cx, cy, _, _ = get_center_position("生成圖片中...", 1)
        s.text("生成圖片中...", cx, cy, 1, 0x00FFFF)
        s.refresh()
        
        result = agent.chat(prompt)
        
        if result:
            img_path = None
            result_str = str(result)
            
            start = result_str.find("](")
            if start != -1:
                end = result_str.find(")", start)
                if end != -1:
                    img_path = result_str[start+2:end]
            
            if not img_path:
                for ext in [".jpg", ".png", ".bmp", ".gif"]:
                    idx = result_str.find(ext)
                    if idx != -1:
                        name_start = idx
                        while name_start > 0 and (result_str[name_start-1].isalnum() or result_str[name_start-1] in "._-"):
                            name_start -= 1
                        img_path = result_str[name_start:idx+len(ext)]
                        break
            
            if img_path:
                # 先加载显示到屏幕
                s.autoRefresh(False)
                s.loadimg(img_path, 0, 0)
                s.refresh()
                
                # 询问是否打印
                s.rect(0, 108, 160, 20, BG_COLOR, 1)
                s.text("按A打印·按B取消", 5, 112, 1, 0x00FF00)
                s.refresh()
                
                # 等待用户选择（最多10秒）
                user_choice = None
                for _ in range(100):
                    btn = read_button()
                    if btn == 1:  # A键 - 打印
                        user_choice = True
                        s.autoRefresh(False)
                        s.loadimg(img_path, 0, 0)
                        s.refresh()
                        break
                    elif btn == 3:  # B键 - 取消
                        user_choice = False
                        s.autoRefresh(False)
                        s.loadimg(img_path, 0, 0)
                        s.refresh()
                        break
                    time.sleep(0.1)
                    
                
                if user_choice == True:
                    # 用户确认打印
                    s.rect(0, 108, 160, 20, BG_COLOR, 1)
                    cx, _, _, _ = get_center_position("打印中...", 1)
                    s.text("打印中...", cx, 112, 0, 0xFFFF00)
                    s.refresh()
                    s.autoRefresh(False)
                    s.loadimg(img_path, 0, 0)
                    s.refresh()
                    try:
                        printer.print_text("✦ 語音生圖 ✦", align="center", scale=2)
                        printer.print_styled_line(style="dashed")
                        printer.print_screen(size_mode="fit")
                        #printer.print_png(img_path, size_mode='fit', align='center')
                        printer.print_styled_line(style="dashed")
                        printer.print_text(description, align="center", scale=1)
                        printer.step(80)
                    except Exception as pe:
                        print(f"打印失败: {pe}")
                        cx, _, _, _ = get_center_position("打印失敗", 1)
                        s.text("打印失敗", cx, 112, 0, 0xFF0000)
                        s.refresh()
                        time.sleep(1)
                
                # 返回主页
                time.sleep(0.5)
                s.rect(0, 0, 160, 128, BG_COLOR, 1)
                tx, ty, _, _ = get_center_position("語音生圖", 2)
                s.text("語音生圖", tx, 5, 2, 0xFFFF00)
                s.line(10, 35, 150, 35, 0x444444)
                cx, cy, _, _ = get_center_position("按A鍵語音輸入描述", 1)
                s.text("按A鍵語音輸入描述", cx, cy, 1, 0xFFFFFF)
                cx2, cy2, _, _ = get_center_position("自動生成2D黑白圖", 1)
                s.text("自動生成2D黑白圖", cx2, cy2 + 20, 1, 0x888888)
                s.text("按A獲取·自動打印", 5, 118, 0, 0xAAAAAA)
                s.refresh()
            else:
                s.rect(0, 0, 160, 128, BG_COLOR, 1)
                display_wrapped_text(result_str, 10, 1, 0xFFFFFF)
                s.refresh()
        else:
            s.rect(0, 0, 160, 128, BG_COLOR, 1)
            cx, cy, _, _ = get_center_position("生成失敗", 1)
            s.text("生成失敗", cx, cy, 1, 0xFF0000)
            s.refresh()
    
    except Exception as e:
        s.rect(0, 0, 160, 128, BG_COLOR, 1)
        cx, cy, _, _ = get_center_position("生成失敗", 1)
        s.text("生成失敗", cx, cy, 1, 0xFF0000)
        display_wrapped_text(str(e), 50, 1, 0xFF0000)
        s.refresh()
        print(f"Agent error: {e}")
    
    gc.collect()

# 主界面
s.rect(0, 0, 160, 128, BG_COLOR, 1)
tx, ty, _, _ = get_center_position("語音生圖", 2)
s.text("語音生圖", tx, 5, 2, 0xFFFF00)
s.line(10, 35, 150, 35, 0x444444)
cx, cy, _, _ = get_center_position("按A鍵語音輸入描述", 1)
s.text("按A鍵語音輸入描述", cx, cy, 1, 0xFFFFFF)
cx2, cy2, _, _ = get_center_position("自動生成2D黑白圖", 1)
s.text("自動生成2D黑白圖", cx2, cy2 + 20, 1, 0x888888)
s.text("按A獲取·自動打印", 5, 118, 0, 0xAAAAAA)
s.refresh()

# 主循环
last_btn = None
while True:
    btn = read_button()
    if btn == 1 and last_btn != 1:
        s.rect(0, 0, 160, 128, BG_COLOR, 1)
        cx, cy, _, _ = get_center_position("請說話...", 1)
        s.text("請說話...", cx, cy, 1, 0x00FF00)
        s.refresh()
        
        # 使用Agent语音识别
        from agent import Agent
        agent = Agent()
        msg = agent.listen()
        
        if msg:
            s.rect(0, 0, 160, 128, BG_COLOR, 1)
            cx, cy, _, _ = get_center_position("識別結果", 1)
            s.text("識別結果", cx, cy - 20, 1, 0x00FFFF)
            display_wrapped_text(msg, 80, 1, 0xFFFFFF)
            s.refresh()
            time.sleep(1.5)
            generate_image(msg)
        else:
            s.rect(0, 0, 160, 128, BG_COLOR, 1)
            cx, cy, _, _ = get_center_position("識別失敗", 1)
            s.text("識別失敗", cx, cy, 1, 0xFF0000)
            s.refresh()
            time.sleep(1)
    
    last_btn = btn
    time.sleep(0.1)
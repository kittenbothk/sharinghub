from future import *
from sensor import Sensor
from koi2 import KOI2
from screen import Screen
from uwifi import WIFI
from agent import Agent
from fileOperations import *
animal = 0
screens = Screen()
sensors = Sensor()
wifipw = []
wifi = WIFI()
wifipw = (read_file('wifi.txt')).split(',')

#wifi.connect('hello', '12345678')
wifi.connect(wifipw[0], wifipw[1])
expert = Agent("expert")
system_prompt = """
你是一個瀕危動物專家，你的職責是介紹小朋友提供的瀕危動物的資訊。回答盡量精簡，控制在90字之內。盡量以繁體字回答。

"""

expert.add_prompt("system", system_prompt)
expert.clear()

koi = KOI2('uart0')
koi.direction(2)
koi.setModel(5)
koi.classifierLoad('/flash/'+'chinaanimals.json')
screens.autoRefresh(False)
animal = 'None'
ans = ''

def screenupdate():
  screens.fill((0, 0, 0))
  screens.text('瀕危物種AI圖鑑',5,2,1,(255, 255, 255))
  screens.text(animal,3,20,1,(0, 170, 0))
  '''
  if ans == "Asking AI" or ans == 'Listening' or ans == None:
    screens.text(ans, 5, 45, 1, (0, 170, 0))
  else:
    screens.text(ans, 5, 15, 1, (0, 170, 0))
  '''
  screens.text(ans, 3, 50, 1, (0, 170, 0))
  screens.text('A:辨認',117,2,1,(255, 255, 255))
  screens.text('B:講解',117,17,1,(255, 255, 255))
  screens.text('M:問AI', 117, 32, 1, (255, 255, 255))
  screens.refresh()
while True:
  koi.read_from_uart()
  if sensors.btnValue('a'):
    animal = koi.strVal
    sleep(0.1)
  if sensors.btnValue('b'):
    if wifi.isconnect():
       ans = 'Asking AI'
       screenupdate()
       ans = expert.chat(animal)
       if ans != None:
        ans = ans.strip()
       screenupdate()
       if ans != None:
           expert.speak(ans)
    sleep(0.1)

  if sensors.btnValue('m'):
    ans = 'Listening'
    screenupdate()
    asr = expert.listen()
    ans = asr
    screenupdate()
    ans = expert.chat(asr)
    if ans != None:
        ans = ans.strip()
    screenupdate()
    if ans != None:
        expert.speak(ans)
    sleep(0.1)
  screenupdate()

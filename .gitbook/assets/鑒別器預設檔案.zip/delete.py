from future import *
from sensor import Sensor
from koi2 import KOI2
from screen import Screen

screens = Screen()
sensors = Sensor()

koi = KOI2('uart0')
koi.displayFileList('/flash',1)
while True:
  screens.fill((0, 0, 0))
  screens.text('鑒別器模型檔案刪除',5,10,1,(255, 255, 255))
  screens.text('按A鍵刪除 瀕危物種AI模型',5,30,1,(170, 0, 0))
  screens.text('按B鍵刪除 中藥材AI模型',5,60,1,(0, 170, 0))
  screens.text('按M鍵刪除 自定義AI模型',5,90,1,(170, 170, 0))
  screens.text('diy.json',30,105,1,(170, 170, 0))
  screens.refresh()
  if sensors.btnValue('a'):
    sleep(0.3)
    koi.deleteFile('/flash/chinaanimals.json')
  if sensors.btnValue('b'):
    sleep(0.3)
    koi.deleteFile('/flash/herb.json')
  if sensors.btnValue('m'):
    sleep(0.3)
    koi.deleteFile('/flash/diy.json')
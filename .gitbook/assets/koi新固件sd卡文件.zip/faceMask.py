import sensor, image, time, lcd
from maix import KPU
import gc
from machine import UART
from board import board_info
from fpioa_manager import fm

lcd.init()
lcd.rotation(0)
lcd.clear()

sensor.reset()                      # Reset and initialize the sensor. It will
                                    # run automatically, call sensor.run(0) to stop
sensor.set_pixformat(sensor.RGB565) # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)   # Set frame size to QVGA (320x240)
sensor.skip_frames(time = 1000)     # Wait for settings take effect.
sensor.set_vflip(True)

od_img = image.Image(size=(320,256), copy_to_fb=False)

anchor = (0.156250, 0.222548, 0.361328, 0.489583, 0.781250, 0.983133, 1.621094, 1.964286, 3.574219, 3.94000)
kpu = KPU()
print("ready load model")
kpu.load("/sd/detect_5.kmodel")
yolo = kpu.Yolo2()
yolo.init(anchor, 0.7, 0.4)
fm.register(board_info.EXT_A, fm.fpioa.UART1_RX, force=True)
fm.register(board_info.EXT_B, fm.fpioa.UART1_TX, force=True)
uart = UART(UART.UART1,115200,8,0,0,timeout=1000,read_buf_len=1024)
uart.write("init ok mask")
print("Start run")
init = False
startTime = time.ticks()
try:
    while True:
        try:
            if not init:
                cmd = uart.readline()
                if cmd:
                    cmd = cmd.decode().strip()
                    if cmd[:2] == "K0":
                        uart.write("K0 3.0.1\n")
                        init = True
        except UnicodeError:
            pass
        #print("mem free:",gc.mem_free())
        img = sensor.snapshot()
        a = od_img.draw_image(img, 0,0)
        od_img.pix_to_ai()
        kpu.run(od_img)
        dect = yolo.run()
        if len(dect) > 0:
            maskNum = 0
            noMaskNum = 0
            maxFace = 0
            mainFace = None
            for l in dect :
                area = l[2] * l[3]
                if area > maxFace:
                    maxFace = area
                    mainFace = l
                if l[4] :
                    a = img.draw_rectangle(l[0],l[1],l[2],l[3], color=(0, 255, 0))
                    a = img.draw_string(l[0],l[1]-24, "with mask", color=(0, 255, 0), scale=2)
                    maskNum+=1
                else:
                    a = img.draw_rectangle(l[0],l[1],l[2],l[3], color=(255, 0, 0))
                    a = img.draw_string(l[0],l[1]-24, "without mask", color=(255, 0, 0), scale=2)
                    noMaskNum+=1
            mainFace[0] -= 40
            mainFace[0] = mainFace[0] + mainFace[2] // 2
            mainFace[1] = mainFace[1] + mainFace[3] // 2
            img.draw_string(40,180, "X:"+str(mainFace[0]), color=(255, 0, 0), scale=2)
            img.draw_string(40,210, "Y:"+str(mainFace[1]), color=(255, 0, 0), scale=2)
            faceAttribute = [maskNum,noMaskNum,mainFace]
            uart.write("K33 %s\n" % (faceAttribute))
        if time.ticks() - startTime < 20000:
            img.draw_rectangle(40,0,239,20,color=(0,0,255),fill=True)
            img.draw_string(40+40, 0, "face mask mode", scale=2,color=(255,255,255))
        lcd.display(img)
        gc.collect()

except Exception as e:
    print(e)
    kpu.deinit()
    del kpu
    gc.collect()
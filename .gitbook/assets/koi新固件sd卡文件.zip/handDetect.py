# 1. Write your code here
# 2. Click the Run button
# 3. See the result in the Output tab

print('Hello World!')
import sensor, image, time, lcd
from maix import KPU
import gc
from machine import UART
from board import board_info
from fpioa_manager import fm

lcd.init()
lcd.rotation(0)
lcd.clear()

sensor.reset()                      # Reset and initialize the sensor. It will
                                    # run automatically, call sensor.run(0) to stop
sensor.set_pixformat(sensor.RGB565) # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)   # Set frame size to QVGA (320x240)
sensor.skip_frames(time = 1000)     # Wait for settings take effect.
sensor.set_vflip(True)

od_img = image.Image(size=(320,256))

anchor = (0.8125, 0.4556, 1.1328, 1.2667, 1.8594, 1.4889, 1.4844, 2.2000, 2.6484, 2.9333)
kpu = KPU()
print("ready load model")
kpu.load("/sd/hand_detect.kmodel")
yolo = kpu.Yolo2()
yolo.init(anchor, 0.7, 0.3)

fm.register(board_info.EXT_A, fm.fpioa.UART1_RX, force=True)
fm.register(board_info.EXT_B, fm.fpioa.UART1_TX, force=True)
uart = UART(UART.UART1,115200,8,0,0,timeout=1000,read_buf_len=1024)
uart.write("init ok hand detect")
print("Start run")
init = False
startTime = time.ticks()
try:
    while True:
        try:
            if not init:
                cmd = uart.read()
                if cmd:
                    cmd = cmd.decode().strip()
                    if cmd[:2] == "K0":
                        uart.write("K0 3.0.1\n")
                        init = True
        except UnicodeError:
            print("buhuo3")
        gc.collect()
        img = sensor.snapshot()
        a = od_img.draw_image(img, 0,0)
        od_img.pix_to_ai()
        kpu.run(od_img)
        dect = yolo.run()
        data = []
        if len(dect) > 0:
            data = []
            maxArea = 0
            mainHand = None
            print("dect:",dect)
            for l in dect :
                if l[2] * l[3] > maxArea:
                    maxArea = l[2] * l[3]
                    mainHand = l
                a = img.draw_rectangle(l[0],l[1],l[2],l[3], color=(0, 255, 0))
                data = [mainHand[0]+mainHand[2]//2-40,mainHand[1]+mainHand[3]//2]
            img.draw_string(40,180, "X:"+str(data[0]), color=(255, 0, 0), scale=2)
            img.draw_string(40,210, "Y:"+str(data[1]), color=(255, 0, 0), scale=2)
            uart.write("K70 %s\n" % (data))
        if time.ticks() - startTime < 20000:
            img.draw_rectangle(40,0,239,20,color=(0,0,255),fill=True)
            img.draw_string(70, 0, "hand detect mode", scale=2,color=(255,255,255))
        lcd.display(img)
except Exception as e:
    print(e)
    kpu.deinit()
    del kpu
    gc.collect()
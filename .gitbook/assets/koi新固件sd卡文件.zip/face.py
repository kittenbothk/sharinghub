# 1. Write your code here
# 2. Click the Run button
# 3. See the result in the Output tab

print('Hello World!')
import sensor, image
import json
import gc
from maix import KPU
from kpuapp import KpuApp


FACE_PIC_SIZE = 64
THRESHOLD = 80.5

dst_point =[(int(38.2946 * FACE_PIC_SIZE / 112), int(51.6963 * FACE_PIC_SIZE / 112)),
            (int(73.5318 * FACE_PIC_SIZE / 112), int(51.5014 * FACE_PIC_SIZE / 112)),
            (int(56.0252 * FACE_PIC_SIZE / 112), int(71.7366 * FACE_PIC_SIZE / 112)),
            (int(41.5493 * FACE_PIC_SIZE / 112), int(92.3655 * FACE_PIC_SIZE / 112)),
            (int(70.7299 * FACE_PIC_SIZE / 112), int(92.2041 * FACE_PIC_SIZE / 112)) ]

anchor = (0.1075, 0.126875, 0.126875, 0.175, 0.1465625, 0.2246875, 0.1953125, 0.25375, 0.2440625, 0.351875, 0.341875, 0.4721875, 0.5078125, 0.6696875, 0.8984375, 1.099687, 2.129062, 2.425937)

def extend_box(x, y, w, h, scale):
    x1_t = x - scale*w
    x2_t = x + w + scale*w
    y1_t = y - scale*h
    y2_t = y + h + scale*h
    x1 = int(x1_t) if x1_t>1 else 1
    x2 = int(x2_t) if x2_t<320 else 319
    y1 = int(y1_t) if y1_t>1 else 1
    y2 = int(y2_t) if y2_t<240 else 239
    cut_img_w = x2-x1+1
    cut_img_h = y2-y1+1
    return x1, y1, cut_img_w, cut_img_h

class FaceDetect(KpuApp):
    
    def __init__(self, recognize=False):
        self.landmark = None
        self.feature = None
        self.recognize = recognize
        # people: {
        #  "name": vector,
        # }
        self.peoples = {}
        # load main model
        super().__init__("face",0x280000)
        # init yolov2
        self.yolo = self.kpu.Yolo2()
        self.yolo.init(anchor, 0.5, 0.2)
        gc.collect()
        if recognize:
            # load landmark model
            self.landmark = KPU()
            self.landmark.load(0x300000)
            gc.collect()
            
            # load feature model
            self.feature = KPU()
            self.feature.load(0x380000)
            gc.collect()

            self.feature_img = image.Image(size=(FACE_PIC_SIZE,FACE_PIC_SIZE), copy_to_fb=False)
            self.feature_img.pix_to_ai()

    def run(self, img, pattern):
        self.kpu.run(img)
        dect = self.yolo.run()
        if len(dect):
            if pattern == "coord":
                face = dect[0]
                img.draw_rectangle(face[0]-5, face[1]-5, face[2]+10, face[3]+10, color=(0, 255, 0))
                return face
            if pattern == "number":
                for face in dect:
                    img.draw_rectangle(face[0]-5, face[1]-5, face[2]+10, face[3]+10, color=(0, 255, 0))
                return len(dect)
                
    def face_feature(self, face, img):
        x1, y1, w, h = extend_box(face[0], face[1], face[2], face[3], scale=0)
        cut_img = img.cut(x1, y1, w, h).resize(128, 128)
        cut_img.pix_to_ai()
        self.landmark.run(cut_img)
        out = self.landmark.get_output()
        face_keypoint = []
        for j in range(5):
            x = int(self.kpu.Act.sigmoid(out[2 * j])*w + x1)
            y = int(self.kpu.Act.sigmoid(out[2 * j + 1])*h + y1)
            # a = img.draw_cross(x, y, size=5, color=(0, 0, 255))
            face_keypoint.append((x,y))
        T = image.get_affine_transform(face_key_point, dst_point)
        a = image.warp_affine_ai(img, self.feature_img, T)
        del face_key_point

        self.feature.run(self.feature_img)
        feature = self.feature.Feat.calculate(self.feature)
        return feature
       
    
    def detect(self, feature):
        # get people from feature
        possibility = 0
        possible_name = None
        for name in self.peoples:
            # compare feature
            score = self.feature.Feat.compare(self.peoples[name], feature)
            if score > THRESHOLD:
                if score > possibility:
                    possibility = score
                    possible_name = name
                
        return possible_name, possibility
    
    def register(self, name, feature):
        self.peoples[name] = feature


    def save(self):
        with open("/sd/face.json", "w") as f:
            json.dump(self.peoples, f)

    def load(self):
        with open("/sd/face.json", "r") as f:
            self.peoples = json.load(f)

    def deinit(self):
        if self.landmark:
            self.landmark.deinit()
            del self.landmark
        if self.feature:
            self.feature.deinit()
            del self.feature
        super().deinit()
        gc.collect()
import sensor, image, time, lcd
from maix import KPU
import gc
from machine import UART
from board import board_info
from fpioa_manager import fm

lcd.init()
lcd.rotation(0)
lcd.clear()

sensor.reset()                      # Reset and initialize the sensor. It will

                                    # run automatically, call sensor.run(0) to stop
sensor.set_pixformat(sensor.RGB565) # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)   # Set frame size to QVGA (320x240)
sensor.skip_frames(time = 1000)     # Wait for settings take effect.
sensor.set_vflip(True)
# sensor.set_hmirror(0)
# sensor.set_vflip(1)

anchor = (0.1075, 0.126875, 0.126875, 0.175, 0.1465625, 0.2246875, 0.1953125, 0.25375, 0.2440625, 0.351875, 0.341875, 0.4721875, 0.5078125, 0.6696875, 0.8984375, 1.099687, 2.129062, 2.425937)
kpu = KPU()
kpu.load(0x280000)
yolo = kpu.Yolo2()
yolo.init(anchor, 0.5, 0.2)

ld5_kpu = KPU()
print("ready load model")
ld5_kpu.load(0x300000)

fac_kpu = KPU()
print("ready load model")
fac_kpu.load("/sd/fac.kmodel")

pos_face_attr = ["Male ", "Mouth Open ", "Smiling ", "Glasses"]
neg_face_attr = ["Female ", "Mouth Closed", "No Smile", "No Glasses"]

# standard face key point position
FACE_PIC_SIZE = 128
dst_point =[(int(38.2946 * FACE_PIC_SIZE / 112), int(51.6963 * FACE_PIC_SIZE / 112)),
            (int(73.5318 * FACE_PIC_SIZE / 112), int(51.5014 * FACE_PIC_SIZE / 112)),
            (int(56.0252 * FACE_PIC_SIZE / 112), int(71.7366 * FACE_PIC_SIZE / 112)),
            (int(41.5493 * FACE_PIC_SIZE / 112), int(92.3655 * FACE_PIC_SIZE / 112)),
            (int(70.7299 * FACE_PIC_SIZE / 112), int(92.2041 * FACE_PIC_SIZE / 112)) ]
            
fm.register(board_info.EXT_A, fm.fpioa.UART1_RX, force=True)
fm.register(board_info.EXT_B, fm.fpioa.UART1_TX, force=True)
uart = UART(UART.UART1,115200,8,0,0,timeout=1000,read_buf_len=1024)
uart.write("init ok face attribute")

RATIO = 0.08
def extend_box(x, y, w, h, scale):
    x1_t = x - scale*w
    x2_t = x + w + scale*w
    y1_t = y - scale*h
    y2_t = y + h + scale*h
    x1 = int(x1_t) if x1_t>1 else 1
    x2 = int(x2_t) if x2_t<320 else 319
    y1 = int(y1_t) if y1_t>1 else 1
    y2 = int(y2_t) if y2_t<240 else 239
    cut_img_w = x2-x1+1
    cut_img_h = y2-y1+1
    return x1, y1, cut_img_w, cut_img_h

print("Start run")
init = False
startTime = time.ticks()
try:
    while True:
        try:
            if not init:
                cmd = uart.readline()
                if cmd:
                    cmd = cmd.decode().strip()
                    if cmd[:2] == "K0":
                        uart.write("K0 3.0.1\n")
                        init = True
        except UnicodeError:
            pass
        data = []
        gc.collect()
        img = sensor.snapshot()
        kpu.run(img)
        dect = yolo.run()
        if len(dect) > 0:
            maxArea = 0
            mainFace = None

            maleNum = 0
            MouthOpen = 0
            smilingNum = 0
            glassesNum = 0
            for l in dect :
                print(l)
                attribute = [0,0,0,0]
                x1, y1, cut_img_w, cut_img_h = extend_box(l[0], l[1], l[2], l[3], scale=RATIO) # 扩大人脸框
                face_cut = img.cut(x1, y1, cut_img_w, cut_img_h)
                a = img.draw_rectangle(l[0],l[1],l[2],l[3], color=(0, 255, 0))
                face_cut_128 = face_cut.resize(128, 128)
                face_cut_128.pix_to_ai()
                ld5_kpu.run(face_cut_128)
                out = ld5_kpu.get_outputs()
                face_key_point = []
                for j in range(5):
                    x = int(kpu.Act.sigmoid(out[2 * j])*cut_img_w + x1)
                    y = int(kpu.Act.sigmoid(out[2 * j + 1])*cut_img_h + y1)
                    a = img.draw_cross(x, y, size=5, color=(0, 0, 255))
                    face_key_point.append((x,y))
                T = image.get_affine_transform(face_key_point, dst_point)
                a = image.warp_affine_ai(img, face_cut_128, T)
                fac_kpu.run(face_cut_128)
                out2 = fac_kpu.get_outputs()
                del face_key_point
                mainFaceMark = False
                if l[2] * l[3] > maxArea:
                    maxArea = l[2] * l[3]
                    mainFace = l
                    mainFaceMark = True
                for i in range(4):
                    th = kpu.Act.sigmoid(out2[i])
                    if th >= 0.7:
                        if mainFaceMark:
                            attribute[i] = 1
                        a = img.draw_string(l[0]+l[2], l[1]+i*16, "%s" %(pos_face_attr[i]), color=(255, 0, 0), scale=1.5)
                        if i == 0:
                            maleNum += 1
                        elif i == 1:
                            MouthOpen += 1
                        elif i == 2:
                            smilingNum += 1
                        elif i == 3:
                            glassesNum += 1
                    else:
                        if mainFaceMark:
                            attribute[i] = 0
                        a = img.draw_string(l[0]+l[2], l[1]+i*16, "%s" %(neg_face_attr[i]), color=(0, 0, 255), scale=1.5)
                del (face_cut_128)
                del (face_cut)
            mainFaceX = l[0]+l[2]//2-40
            mainFaceY = l[1]+l[3]//2
            img.draw_string(40,180, "X:"+str(mainFaceX), color=(255, 0, 0), scale=2)
            img.draw_string(40,210, "Y:"+str(mainFaceY), color=(255, 0, 0), scale=2)
            data.append(len(dect))
            data.append(maleNum)
            data.append(MouthOpen)
            data.append(smilingNum)
            data.append(glassesNum)
            data.append([mainFaceX,mainFaceY,]+attribute)
            uart.write("K34 %s\n" % (data))
        if time.ticks() - startTime < 20000:
            img.draw_rectangle(40,0,239,20,color=(0,0,255),fill=True)
            img.draw_string(80, 0, "face attr mode", scale=2,color=(255,255,255))
        lcd.display(img)
except Exception as e:
    print(e)

    kpu.deinit()
    ld5_kpu.deinit()
    fac_kpu.deinit()

    del kpu
    del ld5_kpu
    del fac_kpu
    gc.collect()
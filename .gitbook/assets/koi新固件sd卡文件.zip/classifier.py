import sensor
import json
import gc
from kpuapp import KpuApp


# k-means clustering
class Classifier(KpuApp):
    
    def __init__(self, model=0x200000):
        super().__init__("cls", model)
        # classes: {name: {
        #   "vector": vector,
        #   "count": 0,
        # }}
        self.classes = {}
        sensor.set_windowing((224, 224))

    def add_feature(self, name, vector):
        if name not in self.classes:
            self.classes[name] = {
                "vector": vector,
                "count": 1,
            }
        else:
            # update vector centroid
            samples = self.classes[name]["count"]
            centroid = self.classes[name]["vector"]
            for i in range(len(centroid)):
                centroid[i] = (centroid[i] * samples + vector[i]) / (samples + 1)
            self.classes[name]["count"] += 1
            
    def classify(self, vector):
        # find closest centroid
        closest = None
        closest_dist = 0
        for name in self.classes:
            centroid = self.classes[name]["vector"]
            dist = 0
            for i in range(len(centroid)):
                dist += (centroid[i] - vector[i]) ** 2
            if closest is None or dist < closest_dist:
                closest = name
                closest_dist = dist
        return closest, closest_dist
    
    def save(self, path):
        with open(path, "w") as f:
            json.dump(self.classes, f)

    def load(self, path):
        with open(path, "r") as f:
            self.classes = json.load(f)

    def deinit(self):
        sensor.set_windowing((320, 240))
        super().deinit()
        gc.collect()

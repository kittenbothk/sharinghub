class ColorTracking:
    def __init__(self):
        self.thresholdMap = {}
    def color_cali(self,img,colorName):
        r = [(320//2)-(50//2), (240//2)-(50//2), 50, 50] # 50x50 center of QVGA.            
        print("Learning thresholds...")
        threshold = [50, 50, 0, 0, 0, 0] # Middle L, A, B values.
        for i in range(60):
            hist = img.get_histogram(roi=r)
            lo = hist.get_percentile(0.01) # 获取1％范围的直方图的CDF（根据需要调整）！
            hi = hist.get_percentile(0.99) # 获取99％范围的直方图的CDF（根据需要调整）！
            # 平均百分位值。
            threshold[0] = (threshold[0] + lo.l_value()) // 2
            threshold[1] = (threshold[1] + hi.l_value()) // 2
            threshold[2] = (threshold[2] + lo.a_value()) // 2
            threshold[3] = (threshold[3] + hi.a_value()) // 2
            threshold[4] = (threshold[4] + lo.b_value()) // 2
            threshold[5] = (threshold[5] + hi.b_value()) // 2
#             for blob in img.find_blobs([threshold], pixels_threshold=100, area_threshold=100, merge=True, margin=10):
#                 pass
#                 img.draw_rectangle(blob.rect())
#                 img.draw_cross(blob.cx(), blob.cy())
#                 img.draw_rectangle(r)
            self.thresholdMap[colorName] = threshold
            
    def color_tracking(self,img,colorName):
        coord = None
        for blob in img.find_blobs([self.thresholdMap[colorName]], pixels_threshold=100, area_threshold=100, merge=True, margin=10):
            img.draw_rectangle(blob.rect())
            img.draw_cross(blob.cx(), blob.cy())
            coord = blob.rect()
            print(blob.rect())
        return coord

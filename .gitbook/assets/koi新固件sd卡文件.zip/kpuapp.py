import gc
from maix import KPU, GPIO

class KpuApp:
    
    def __init__(self, name, model):
        self.name = name
        self.kpu = KPU()
        if model:
            self.kpu.load(model)

    def run(self, img):
        self.kpu.run(img)
        vector = self.kpu.get_outputs()
        return vector

    def deinit(self):
        self.kpu.deinit()
        del self.kpu
        gc.collect()
        
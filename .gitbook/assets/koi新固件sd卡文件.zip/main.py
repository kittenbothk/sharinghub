# Text Drawing
#
# This example shows off drawing text on the CanMV Cam.

from maix import GPIO
from fpioa_manager import fm
from board import board_info
import json
import gc

configMain = {
    "mainFile":"koi.py"
}
cfg = json.dumps(configMain)

#btn
fm.register(board_info.BUTTON_A, fm.fpioa.GPIOHS6)
fm.register(board_info.BUTTON_B, fm.fpioa.GPIOHS8)
btnA = GPIO(GPIO.GPIOHS6, GPIO.IN, GPIO.PULL_UP)
btnB = GPIO(GPIO.GPIOHS8, GPIO.IN, GPIO.PULL_UP)
s = True

def readConfigMain():
    tmp = None
    try:
        with open('/flash/configMain.json', 'rb') as f:
            tmp = json.loads(f.read())
    except Exception as e:
        print("read error")
        with open('/flash/configMain.json', "w") as f:
            f.write(cfg)
        import machine
        machine.reset()
    return tmp

if btnA.value() == 0:
    import lcd, image
    import json
    import time
    lcd.init()
    lcd.rotation(0)
    lcd.clear()
    mode = [
    {"text":"classic","file":"koi.py"},
    {"text":"face_mask","file":"faceMask.py"},
    {"text":"ASR","file":"koiAsr.py"},
    {"text":"face attribute","file":"faceAttribute.py"},
    {"text":"hand detect","file":"handDetect.py"},
    ]
    select = 0
    y = 0
    img = image.Image()
    img.draw_rectangle(0, 0, 239, 20,color=(0, 0, 255),fill=True)
    img.draw_string(60, 0, "select mode", scale=2,color=(255,255,255))
    lcd.display(img)
    num = 0
    for i in mode:
        num+=1
        y+=35
        img.draw_rectangle(0, y, 239, 25, color = (255, 255, 255), fill=True)
        img.draw_string(5, y+2, str(num)+"."+i["text"], scale=2,color=(0,0,0))
    img.draw_string(0, 220, "BNTA:Select  BNTB:Enter", scale=2,color=(255,255,255))
    lcd.display(img)
    while btnB.value() == 1:
        if btnA.value() == 0:
            if s:
                selectY = 35 * select
                if select != 0:
                    img.draw_rectangle(190, selectY, 49, 25, color = (255, 255, 255), fill=True)
                select += 1
                if select > len(mode):
                    select = 1
                selectY = 35 * select
                img.draw_arrow(239, selectY+12, 200, selectY+12, color = (0, 0, 0), thickness=8)
                s = False
                lcd.display(img)

        else:
            s = True
    img.clear()
    img.draw_rectangle(39, 39, 160, 100, color = (0, 0, 255), fill=True)
    img.draw_string(49, 69, "loading...", scale=2,color=(255,255,255))
    lcd.display(img)
    del(lcd)
    del(img)
    tmp = {"mainFile":mode[select-1]["file"]}
    tmpdumps = json.dumps(tmp)
    os.remove('/flash/configMain.json')
    time.sleep(1)
    with open('/flash/configMain.json', "w") as f:
        f.write(tmpdumps)
    print("tmpdumps",tmpdumps)
    import machine
    machine.reset()

del(GPIO)
del(fm)
gc.collect()
tmp = readConfigMain()
print("this....",tmp["mainFile"])
with open(tmp["mainFile"], 'r') as fp:
    exec(fp.read())



        
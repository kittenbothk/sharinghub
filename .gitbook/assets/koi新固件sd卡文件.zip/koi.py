print("koi file ............")
import sensor, image, time, lcd

import network
from maix import KPU, GPIO, I2S
from machine import UART, reset
from board import board_info
from fpioa_manager import fm

from face import FaceDetect
from classifier import Classifier

import gc
from machine import Timer

from speech import *

VERSION = "v3.0.1"

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)

def on_timer(timer):
  timer.callback_arg().state()

class UIMsg:

    def __init__(self, content, x=0,y=0,color=lcd.GREEN,delay=3000,scale=2):
        self.content = content
        self.x = x
        self.y = y
        self.color = color
        self.timeout = delay + time.ticks_ms()
        self.scale = scale

    def update(self, img):
        if time.ticks_ms() > self.timeout:
            return True
        img.draw_string(self.x+40, self.y, self.content, self.color, scale=self.scale)


class KOI:

    def __init__(self):
        lcd.init()
        lcd.rotation(0)
        lcd.clear()
        try:
            lcd.display(image.Image('/flash/koi.jpg'))
        except:
            pass

        self.s_fmt = None
        self.s_size = None

        self.sensor_mode()
        
        # sensor.set_hmirror(0)
        # to make qrcode works
        sensor.set_vflip(True)

        sensor.run(1)
        sensor.skip_frames(time = 2000)

        self.model = None
        self.uicomp = {}

        # peripheral
        # uart
        fm.register(board_info.EXT_A, fm.fpioa.UART1_RX, force=True)
        fm.register(board_info.EXT_B, fm.fpioa.UART1_TX, force=True)
        self.uart = UART(UART.UART1,115200,8,0,0,timeout=1000,read_buf_len=1024)
        # button
        fm.register(board_info.BUTTON_A, fm.fpioa.GPIOHS6)
        fm.register(board_info.BUTTON_B, fm.fpioa.GPIOHS8)
        self.btnA = GPIO(GPIO.GPIOHS6, GPIO.IN, GPIO.PULL_UP)
        self.btnB = GPIO(GPIO.GPIOHS8, GPIO.IN, GPIO.PULL_UP)
        # i2s
        fm.register(10, fm.fpioa.I2S0_IN_D0, force=True)
        fm.register(12, fm.fpioa.I2S0_SCLK, force=True)
        fm.register(15, fm.fpioa.I2S0_WS, force=True)
        # wifi
        fm.register(board_info.WIFI_TX,fm.fpioa.UART2_TX, force=True)
        fm.register(board_info.WIFI_RX,fm.fpioa.UART2_RX, force=True)
        wifiUart = UART(UART.UART2,460800,timeout=1000, read_buf_len=1024)
        self.wifi = network.ESPLINK(wifiUart)
        
        self.thresholdMap = {}

        self.audio = speech()

    def sensor_mode(self, fmt=sensor.RGB565, size=sensor.QVGA):
        if self.s_fmt != fmt or self.s_size != size:
            sensor.set_pixformat(fmt)
            sensor.set_framesize(size)
            self.s_fmt = fmt
            self.s_size = size

    def loadImage(self, path, delay=2000):
        img = image.Image(path)
        img.draw_string(40, 0, path,scale=1.6,color=(0,255,0)) 
        lcd.display(img)
        time.sleep_ms(delay)

    def saveImage(self, path):
        n = sensor.snapshot()
        n.save(path)

    def colorCalibrate(self,key):
        r = [(320//2)-(50//2), (240//2)-(50//2), 50, 50]
        print("Auto algorithms done. Hold the object you want to track in front of the camera in the box.")
        print("MAKE SURE THE COLOR OF THE OBJECT YOU WANT TO TRACK IS FULLY ENCLOSED BY THE BOX!")
        for i in range(60):
            self.img = sensor.snapshot()
            self.img.draw_rectangle(r)
            lcd.display(self.img)

        print("Learning thresholds...")
        threshold = [50, 50, 0, 0, 0, 0] # Middle L, A, B values.
        for i in range(60):
            self.img = sensor.snapshot()
            hist = self.img.get_histogram(roi=r)
            lo = hist.get_percentile(0.01) # Get the CDF of the histogram at the 1% range (ADJUST AS NECESSARY)!
            hi = hist.get_percentile(0.99) # Get the CDF of the histogram at the 99% range (ADJUST AS NECESSARY)!
            # Average in percentile values.
            threshold[0] = (threshold[0] + lo.l_value()) // 2
            threshold[1] = (threshold[1] + hi.l_value()) // 2
            threshold[2] = (threshold[2] + lo.a_value()) // 2
            threshold[3] = (threshold[3] + hi.a_value()) // 2
            threshold[4] = (threshold[4] + lo.b_value()) // 2
            threshold[5] = (threshold[5] + hi.b_value()) // 2
            for blob in self.img.find_blobs([threshold], pixels_threshold=100, area_threshold=100, merge=True):
                self.img.draw_rectangle(blob.rect())
                self.img.draw_cross(blob.cx(), blob.cy())
                self.img.draw_rectangle(r)
            lcd.display(self.img)
        self.thresholdMap[key] = threshold
        print("Thresholds learned...")
        
        print("Tracking colors...")
    
    def colorTrack(self,img,key):
        coord = None
        maxArea = 0
        for blob in img.find_blobs([self.thresholdMap[key]], pixels_threshold=100, area_threshold=100, merge=True, margin=10):
            img.draw_rectangle(blob.rect())
            img.draw_cross(blob.cx(), blob.cy())
            if blob.rect()[2] * blob.rect()[3] > maxArea:
                maxArea = blob.rect()[2] * blob.rect()[3]
                coord = blob.rect()
        return coord

    def lineTrack(self,img,key):
        th = self.thresholdMap[key]
        line = img.get_regression([th])
        if line:
            line = line.line()
            img.draw_arrow(line[2],line[3],line[0],line[1],color=(12,169,221),thickness=10)
        return line
        
        

    def find_circle(self, img, th=4000):
        circles = None
        maxArea = 0
        for c in img.find_circles(roi=(60,20,200,200),threshold=th, x_margin=10, y_margin=10, r_margin=10,r_min=2, r_max=100, r_step=2):
            img.draw_circle(c.x(), c.y(), c.r(), color=(0, 255, 0))
            if c.r() > maxArea:
                maxArea = c.r()
                circles = c
        if circles:
            return circles
        return None
    
    def find_rect(self, img, th=10000):
        rect = None
        maxArea = 0
        for r in img.find_rects(threshold = th,roi=(60,20,200,200)):
            img.draw_rectangle(r.rect(), color = (0, 255, 0))
            if r.rect()[2] * r.rect()[3] > maxArea:
                maxArea = r.rect()[2] * r.rect()[3]
                rect = r
        if rect:
            return rect
        return None
    
    def find_line(self,img,th=4000):
        line = img.find_lines(threshold = th, theta_margin = 25, rho_margin = 25,roi=(60,20,200,200))
        for l in line:
            if (min_degree <= l.theta()) and (l.theta() <= max_degree):
                img.draw_line(l.line(), color = (0, 255, 0))
        if line:
            return line[0]
        return None
    

    # process makecode command, in format: K<cmd> <arg1> <arg2>...
    def makecode_parse(self, cmd):
        cmd = cmd.decode().strip()
        
        if cmd[0] != 'K':
            raise ValueError("invalid command")
        cmd = cmd[1:].split(' ')
        ret = [cmd[0], None]
        if cmd[0] == '0':
            ret[1] = VERSION
        elif cmd[0] == '1': # display image
            self.loadImage(cmd[1])
        elif cmd[0] == '2': # save image
            self.saveImage(cmd[1])
        elif cmd[0] == '3': # read button
            _a = 0 if self.btnA.value() == 1 else 1
            _b = 0 if self.btnB.value() == 1 else 1
            ret[1] = "%d %d" % (_a, _b)
        elif cmd[0] == '4': # print x,y,delay,text
            msg = UIMsg(" ".join(cmd[4:]), int(cmd[1]), int(cmd[2]), delay=int(cmd[3]))
            self.uicomp[cmd[4]] = msg
        elif cmd[0] == '6': # lcd direction
            lcd.rotation(int(cmd[1]))
        elif cmd[0] == '10': # find circle
            circle = self.find_circle(self.img, int(cmd[1]))
            if circle:
                ret[1] = "%d %d %d" % (circle.x()-40, circle.y(), circle.r())
        elif cmd[0] == '11': # find rect
            rect = self.find_rect(self.img, int(cmd[1]))
            if rect:
                ret[1] = "%d %d %d %d" % (rect.x()+rect.w()//2-40, rect.y()+rect.h()//2, rect.w(),rect.h())
        elif cmd[0] == '12':
            line = self.lineTrack(self.img,cmd[1])
            if line:
                ret[1] = "%d %d %d %d" % (line[0]-40,line[1],line[2]-40,line[3])
        elif cmd[0] == '15':
            rec = self.colorTrack(self.img,cmd[1])
            if rec:
                ret[1] = "%d %d %d %d" % (rec[0]+rec[2]//2-40,rec[1]+rec[3]//2,rec[2],rec[3])
        elif cmd[0] == '16':
            self.colorCalibrate(cmd[1])
        elif cmd[0] == '20': # qr code
            tags = self.img.find_qrcodes()
            if tags:
                ret[1] = tags[0].payload()
                self.img.draw_rectangle(tags[0].rect())
        elif cmd[0] == '22': # barcode
            tags = self.img.find_barcodes()
            if tags:
                ret[1] = tags[0].payload()
                self.img.draw_rectangle(tags[0].rect())
        elif cmd[0] == '23': # april tag
            tags = self.img.find_apriltags(roi=(60,20,200,200),families=0x1f)
            for tag in tags:
                self.img.draw_rectangle(tag.rect(), color=(255, 0, 0))
                self.img.draw_cross(tag.cx(), tag.cy(), color=(0, 255, 0))
                ret[1] = "%d %d %d" % (tag.id(), tag.cx(), tag.cy())
        
        # 30~39: face detect related
        elif cmd[0] == '30': # init face detect
            if self.model:
                self.model.deinit()
            self.model = FaceDetect(False) # enable face detect by default
        elif cmd[0] == '31': # get face position
            ret[1] = ""
            if self.model:
                face = self.model.run(self.img,"coord")
                if face:
                    ret[1] = "%d %d %d %d" % (face[0]-40, face[1], face[2], face[3])
        elif cmd[0] == '32': # number for face
            ret[1] = ""
            if self.model:
                face = self.model.run(self.img,"number")
                if face:
                    ret[1] = "%d" % (face)
        elif cmd[0] == '33': # detect
            ret[1] = ""
            if self.model:
                face = self.model.run(self.img)
                if face:
                    feature = self.model.face_feature(face, self.img)
                    name, p = self.model.detect(feature)
                    if name:
                        ret[1] = "%s %d" % (name, p)
        elif cmd[0] == '34': # add face
            ret[1] = ""
            if self.model:
                face = self.model.run(self.img)
                if face:
                    feature = self.model.face_feature(face, self.img)
                    self.model.register(cmd[1], feature)
                    ret[1] = "ok"
        elif cmd[0] == '35': # save
            if self.model:
                self.model.save()
                ret[1] = "ok"
        elif cmd[0] == '36': # load
            if self.model:
                self.model.load()
                ret[1] = "ok"
        # 40~49: classifier related
        elif cmd[0] == '40': # init classifier
            if self.model:
                self.model.deinit()
            self.model = Classifier()
        elif cmd[0] == '41': # add class
            if self.model:
                vec = self.model.run(self.img)
                self.model.add_feature(cmd[1], vec)
                ret[1] = "ok"
        elif cmd[0] == '42': # classify
            if self.model:
                vec = self.model.run(self.img)
                name, p = self.model.classify(vec)
                ret[1] = "%s %d" % (name, p)
        elif cmd[0] == '43': # save
            if self.model:
                self.model.save(cmd[1])
                ret[1] = "ok"
        elif cmd[0] == '44': # load
            if self.model:
                self.model.load(cmd[1])
                ret[1] = "ok"
        # 50~59: wifi related
        elif cmd[0] == '50':
            self.wifi.joinap(cmd[1], cmd[2])
        elif cmd[0] == '54':
            r = self.wifi.ipaddr()
            ret[1] = r
        elif cmd[0] ==  '61': # recorded audio
            self.audio.recorded(int(cmd[1]))
        elif cmd[0] ==  '62': # play audio
            pass
        elif cmd[0] ==  '63': # start asr
            pass
        elif cmd[0] == '98': # stop all model
            if self.model:
                self.model.deinit()
                self.model = None
                ret[1] = "ok"
        elif cmd[0] == '99': # reset
            reset()
        else:
            raise ValueError("unknow command "+cmd[0])
        return ret


    def parse_uart(self):
        cmd = self.uart.readline()
        if cmd:
            try:
                [cmd, result] = self.makecode_parse(cmd)
                if result != None:
                    self.uart.write("K%s %s\n" % (cmd, result))
            except Exception as err:
                print(err)
            gc.collect()
            

    def run(self):
        t0 = time.ticks_ms()
        while True:
            self.img = sensor.snapshot()
            gc.collect()
            if self.uart.any():
                self.parse_uart()
            # update ui component
            for k in self.uicomp:
                if self.uicomp[k].update(self.img):
                    del self.uicomp[k]
            lcd.display(self.img)
        
koi = KOI()
koi.run()



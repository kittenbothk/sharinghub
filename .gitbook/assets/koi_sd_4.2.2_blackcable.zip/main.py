import image, time, lcd
import maix
import hashlib
import machine
import json
import os

CHUNK_SIZE = 4096

lcd.init()
lcd.rotation(0)
lcd.clear()

img = image.Image(size=(240,240), copy_to_fb=False)
img.draw_string(8, 0, "Flash Firmware", scale=2)

def check_id():
    uid = machine.unique_id()
    uidStr = ""
    for i in uid[0:6]:
        uidStr += hex(i)
    
    if not "history.json" in os.listdir():
        with open("/sd/history.json","w") as f:
            json.dump([],f)

    historyId = None
    with open("/sd/history.json","r") as f:
        historyId = json.load(f)
        print(historyId)
    if uidStr in historyId:
        img.draw_string(8, 0, "update completed", scale=2)
        img.draw_string(8, 30, "Shut down and exit the sd card", scale=2)
        return False
    else:
        historyId.append(uidStr)
        with open("/sd/history.json","w") as f:
            json.dump(historyId,f)
        return True

def get_firmware_size(filename):
    with open("/sd/%s" % filename, "rb") as fp:
        fp.seek(0, 2)
        return fp.tell()

def flash_firmware(addr, filename):
    prefix = None
    hash256 = None
    if filename[-4:] == ".bin":
        prefix = b'\x02'
        sz = get_firmware_size(filename)
        print("Firmware size: %d bytes" % sz)
        prefix += sz.to_bytes(4, "little")
        hash256 = hashlib.sha256()

    x = 8
    y = 24+8
    with open("/sd/%s" % filename, "rb") as fp:
        while True:
            if prefix:
                data = prefix + fp.read(CHUNK_SIZE - len(prefix))
                prefix = None
            else:
                data = fp.read(CHUNK_SIZE)
            if hash256:
                hash256.update(data)
            if not data:
                break
            print("Writing %d bytes to 0x%x" % (len(data), addr))
            maix.utils.flash_write(addr, data)
            addr += len(data)
            img.draw_string(x, y, ".", scale=1)
            lcd.display(img)
            x += 8
            if x > 240:
                x = 8
                y += 8
                if y > 240:
                    img.draw_rectangle((0,24,240,240), fill=True, color=(0, 0, 255))
                    lcd.clear(0xf100)
                    y = 24+8
        if hash256:
            _h = hash256.digest()
            maix.utils.flash_write(addr, _h)
            print("hash %d bytes to 0x%x" % (len(_h), addr))
            time.sleep(1)



def main():
    if not check_id():
        return
    # 1. Open firmware.txt at /sd/firmware.txt
    firmwares = []
    try:
        with open("/sd/firmware.txt", "r") as f:
            for line in f.readlines():
                line = line.strip()
                if len(line) > 0:
                    [addr, filename] = line.split(" ")
                    firmwares.append((addr, filename))
    except:
        img.draw_string(8, 24, "Error reading firmware.txt", scale=2)
        lcd.display(img)
        return
    
    # 2. flash each firmware
    for (addr, filename) in firmwares:
        img.draw_rectangle((0,0,240,240), fill=True, color=(0, 0, 255))
        img.draw_string(8, 0, "Flashing %s" % filename, scale=2)
        lcd.display(img)
        try:
            addr = int(addr, 16)
            print("Flashing %s to 0x%x" % (filename, addr))
            flash_firmware(addr, filename)
        except Exception as e:
            print(e)
            img.draw_string(8, 24, "Error flashing %s" % filename, scale=2)

            lcd.display(img)
            return
main()
img.draw_rectangle((0,0,240,240), fill=True, color=(0, 0, 255))
img.draw_string(40, 0, "Flash succeed!", scale=2)
lcd.display(img) 


